#include <iostream>
using namespace std;

void dif (int&a, int&b){



a=a-b;
b=a-b;

}
main(){
int n1,n2;

cout<<"Digite N1:";
cin>>n1;

cout<<"Digite N2:";
cin>>n2;

dif(n1,n2);


if (n1>n2)
cout<<" A diferenca = "<<n1;


else
if (n2>n1)
cout<<" A diferenca = "<<n2;

}
