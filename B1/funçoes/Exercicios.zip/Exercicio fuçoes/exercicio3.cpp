#include <iostream>
using namespace std;
void maiormenor (int &a, int&b){

int aux;

if(a>b){

aux=b;
b=a;
a=aux;
}
}

main(){
int a,b;

cout<<"Digite um valor:";
cin>>a;

cout<<"Digite o segundo valor:";
cin>>b;

maiormenor(a,b);

cout<<"O maior numero digitado ="<<b<<endl;
cout<<"O menor numero digitado ="<<a<<endl;
}



